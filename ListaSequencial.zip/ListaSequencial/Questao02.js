var num;

num = parseFloat(window.prompt("Digite um número: "));
console.log(`O número informado foi ${num}`);