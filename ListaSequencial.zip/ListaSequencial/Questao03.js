var num1, num2;
num1 = parseFloat(window.prompt(`Digite um número: `));
num2 = parseFloat(window.prompt("Digite o segundo número: "))

console.log(`A soma dos dois números é: ${num1 + num2}`);