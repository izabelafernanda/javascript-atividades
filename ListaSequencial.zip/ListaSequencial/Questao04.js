var nota1, nota2, nota3, nota4;

nota1 = parseFloat(window.prompt(`Digite uma nota: `));
nota2 = parseFloat(window.prompt(`Digite uma nota: `));
nota3 = parseFloat(window.prompt(`Digite uma nota: `));
nota4 = parseFloat(window.prompt(`Digite uma nota: `));
console.log(`A média é: ${nota1 + nota2 + nota3 + nota4 / 4}`);