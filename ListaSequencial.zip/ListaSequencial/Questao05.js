var metros;

metros = parseFloat(window.prompt(`Digite o valor do metro: `));

console.log(`Em centímetros será ${metros * 100}cm`);

