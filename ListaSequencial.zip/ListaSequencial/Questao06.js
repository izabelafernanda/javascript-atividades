var raio;

parseFloat(window.prompt(`Digite o valor do raio: `));
console.log(`A área ${2 * 3.14 * raio}`)