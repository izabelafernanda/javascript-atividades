var lado;

lado = parseFloat(window.prompt(`Digite o valor do lado: `));

console.log(`A área do quadrado será: ${lado * lado}`)
console.log(`O dobro da área do quadrado será: ${2 * (lado * lado)}`)