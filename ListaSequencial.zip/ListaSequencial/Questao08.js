var hora, horames;

hora = parseFloat(window.prompt(`Digite quanto você ganha por hora: `));
horames = parseFloat(window.prompt(`Digite o número de horas trabalhadas no mês: `));

console.log(`O total do salário no mês é de: ${hora * horames}`);
